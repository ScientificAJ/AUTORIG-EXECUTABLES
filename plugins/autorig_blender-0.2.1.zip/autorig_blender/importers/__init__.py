"""Rig result import utilities."""
