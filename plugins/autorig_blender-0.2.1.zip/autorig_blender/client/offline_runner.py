"""Offline fallback for local Blender execution.

This intentionally keeps behavior lightweight and deterministic.
"""

from __future__ import annotations


def run_offline_stub(mesh_name: str) -> dict[str, object]:
    return {
        "mode": "offline",
        "mesh": mesh_name,
        "status": "ok",
        "note": "Offline fallback executed with reduced feature set",
    }
