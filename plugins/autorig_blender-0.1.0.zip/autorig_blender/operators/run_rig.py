"""Run rig operator with API-first and offline fallback behavior."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None

from ..client.api_client import ApiConfig, healthz
from ..client.offline_runner import run_offline_stub


if bpy is not None:
    class AUTORIG_OT_run_rig(bpy.types.Operator):
        bl_idname = "autorig.run_rig"
        bl_label = "Run AutoRig"

        def execute(self, context):  # noqa: D401 - Blender execute API
            prefs = context.preferences.addons["autorig_blender"].preferences
            obj = context.active_object
            mesh_name = obj.name if obj else "<none>"

            if prefs.offline_mode == "on":
                result = run_offline_stub(mesh_name)
                self.report({"INFO"}, f"Offline rig: {result['status']}")
                return {"FINISHED"}

            api_ok = healthz(ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0))
            if api_ok:
                self.report({"INFO"}, "API-first execution path ready")
                return {"FINISHED"}

            if prefs.offline_mode == "auto":
                result = run_offline_stub(mesh_name)
                self.report({"WARNING"}, f"API unavailable, fallback: {result['status']}")
                return {"FINISHED"}

            self.report({"ERROR"}, "API unavailable and offline mode is off")
            return {"CANCELLED"}


    CLASSES = [AUTORIG_OT_run_rig]
else:
    CLASSES = []
