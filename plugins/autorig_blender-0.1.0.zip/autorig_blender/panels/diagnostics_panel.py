"""Diagnostics panel for runtime visibility."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None


if bpy is not None:
    class AUTORIG_PT_diagnostics_panel(bpy.types.Panel):
        bl_label = "AutoRig Diagnostics"
        bl_idname = "AUTORIG_PT_diagnostics_panel"
        bl_space_type = "VIEW_3D"
        bl_region_type = "UI"
        bl_category = "AutoRig AI"
        bl_parent_id = "AUTORIG_PT_main_panel"

        def draw(self, context):  # noqa: D401 - Blender draw API
            layout = self.layout
            scene = context.scene
            layout.label(text=f"Health: {getattr(scene, 'autorig_last_health', 'unknown')}")
            layout.label(text="Contract: v1")


    CLASSES = [AUTORIG_PT_diagnostics_panel]
else:
    CLASSES = []
