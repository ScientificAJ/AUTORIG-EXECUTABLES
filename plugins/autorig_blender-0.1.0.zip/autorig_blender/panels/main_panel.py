"""Primary Blender sidebar panel."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None


if bpy is not None:
    class AUTORIG_PT_main_panel(bpy.types.Panel):
        bl_label = "AutoRig AI"
        bl_idname = "AUTORIG_PT_main_panel"
        bl_space_type = "VIEW_3D"
        bl_region_type = "UI"
        bl_category = "AutoRig AI"

        def draw(self, context):  # noqa: D401 - Blender draw API
            layout = self.layout
            layout.operator("autorig.health_check", icon="CHECKMARK")
            layout.operator("autorig.run_rig", icon="ARMATURE_DATA")
            layout.operator("autorig.export_result", icon="EXPORT")


    CLASSES = [AUTORIG_PT_main_panel]
else:
    CLASSES = []
