"""Addon preferences and runtime settings."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover - imported in Blender runtime
    bpy = None


if bpy is not None:
    from .client.api_client import ApiConfig, get_preset, get_preset_index

    class AutoRigPresetSearchResult(bpy.types.PropertyGroup):
        preset_id: bpy.props.StringProperty(name="Preset ID", default="")  # type: ignore[attr-defined]
        category: bpy.props.StringProperty(name="Category", default="")  # type: ignore[attr-defined]
        complexity: bpy.props.StringProperty(name="Complexity", default="")  # type: ignore[attr-defined]
        targets: bpy.props.StringProperty(name="Targets", default="")  # type: ignore[attr-defined]
        tags: bpy.props.StringProperty(name="Tags", default="")  # type: ignore[attr-defined]

    class AUTORIG_UL_preset_results(bpy.types.UIList):
        def draw_item(  # noqa: D401 - Blender UIList API
            self,
            context,
            layout,
            data,
            item,
            icon,
            active_data,
            active_propname,
            index,
        ):
            del context, data, icon, active_data, active_propname, index
            txt = f"{item.preset_id} ({item.category}, {item.complexity})"
            layout.label(text=txt)

    class AUTORIG_OT_preset_search(bpy.types.Operator):
        bl_idname = "autorig.preset_search"
        bl_label = "Search Presets"
        bl_description = "Fetch the preset index from the API and filter results"

        def execute(self, context):  # noqa: D401 - Blender execute API
            prefs = context.preferences.addons["autorig_blender"].preferences
            cfg = ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0)
            try:
                payload = get_preset_index(cfg)
            except Exception as exc:
                prefs.preset_search_status = f"Preset index fetch failed: {exc}"
                return {"CANCELLED"}

            presets = payload.get("presets", [])
            if not isinstance(presets, list):
                prefs.preset_search_status = "Preset index invalid (missing presets list)"
                return {"CANCELLED"}

            q = (prefs.preset_query or "").strip().lower()
            limit = max(1, int(getattr(prefs, "preset_search_limit", 60)))

            results: list[dict[str, object]] = []
            for raw in presets:
                if not isinstance(raw, dict):
                    continue
                pid = str(raw.get("id", "")).strip()
                if not pid:
                    continue
                category = str(raw.get("category", "")).strip()
                complexity = str(raw.get("complexity", "")).strip()
                targets = raw.get("targets", [])
                tags = raw.get("tags", [])
                targets_list = targets if isinstance(targets, list) else []
                tags_list = tags if isinstance(tags, list) else []

                hay = " ".join(
                    [
                        pid,
                        category,
                        complexity,
                        " ".join(str(x) for x in tags_list),
                        " ".join(str(x) for x in targets_list),
                    ]
                ).lower()
                if q and q not in hay:
                    continue

                results.append(
                    {
                        "id": pid,
                        "category": category,
                        "complexity": complexity,
                        "targets": ",".join(str(x) for x in targets_list),
                        "tags": ",".join(str(x) for x in tags_list),
                    }
                )
                if len(results) >= limit:
                    break

            try:
                prefs.preset_results.clear()
            except Exception:
                # Older Blender versions may not implement clear() on CollectionProperty.
                while prefs.preset_results:
                    prefs.preset_results.remove(0)

            for r in results:
                item = prefs.preset_results.add()
                item.preset_id = str(r.get("id", ""))
                item.category = str(r.get("category", ""))
                item.complexity = str(r.get("complexity", ""))
                item.targets = str(r.get("targets", ""))
                item.tags = str(r.get("tags", ""))

            prefs.preset_results_index = 0
            prefs.preset_search_status = f"Preset results: {len(results)} shown"
            return {"FINISHED"}

    class AUTORIG_OT_preset_use_selected(bpy.types.Operator):
        bl_idname = "autorig.preset_use_selected"
        bl_label = "Use Selected Preset"
        bl_description = "Apply the selected preset ID and load its vector parameters"

        def execute(self, context):  # noqa: D401 - Blender execute API
            prefs = context.preferences.addons["autorig_blender"].preferences
            if not prefs.preset_results:
                prefs.preset_search_status = "No preset selected (run search first)"
                return {"CANCELLED"}

            idx = int(getattr(prefs, "preset_results_index", 0))
            if idx < 0 or idx >= len(prefs.preset_results):
                prefs.preset_search_status = "Invalid preset selection index"
                return {"CANCELLED"}

            entry = prefs.preset_results[idx]
            preset_id = str(entry.preset_id or "").strip()
            if not preset_id:
                prefs.preset_search_status = "Selected preset entry is empty"
                return {"CANCELLED"}

            prefs.motion_preset_id = preset_id

            cfg = ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0)
            try:
                preset = get_preset(cfg, preset_id)
                vp = preset.get("vector_parameters", {})
                if isinstance(vp, dict):
                    direction = vp.get("direction")
                    if (
                        isinstance(direction, (list, tuple))
                        and len(direction) == 3
                        and all(isinstance(x, (int, float)) for x in direction)
                    ):
                        prefs.motion_direction = (  # type: ignore[assignment]
                            float(direction[0]),
                            float(direction[1]),
                            float(direction[2]),
                        )
                    if isinstance(vp.get("intensity"), (int, float)):
                        prefs.motion_intensity = float(vp["intensity"])
                    if isinstance(vp.get("frequency"), (int, float)):
                        prefs.motion_frequency = float(vp["frequency"])
                    if isinstance(vp.get("damping"), (int, float)):
                        prefs.motion_damping = float(vp["damping"])
                prefs.preset_search_status = f"Selected preset: {preset_id}"
            except Exception as exc:
                prefs.preset_search_status = (
                    f"Selected preset: {preset_id} (details fetch failed: {exc})"
                )
            return {"FINISHED"}

    class AutoRigPreferences(bpy.types.AddonPreferences):
        bl_idname = "autorig_blender"

        api_url: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="API URL",
            default="http://127.0.0.1:8000",
        )
        timeout_ms: bpy.props.IntProperty(  # type: ignore[attr-defined]
            name="Timeout (ms)",
            default=15000,
            min=1000,
            max=120000,
        )
        offline_mode: bpy.props.EnumProperty(  # type: ignore[attr-defined]
            name="Offline Mode",
            items=[
                ("auto", "Auto", "Fallback when API unavailable"),
                ("on", "On", "Always use offline fallback"),
                ("off", "Off", "Require API"),
            ],
            default="auto",
        )
        enable_geometric_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Geometric Inference",
            default=False,
            description="Allows EXPERIMENTAL Draw -> Recognize -> Correct geometric inference mode.",
        )
        enable_hair_rigging_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Hair Rigging",
            default=False,
            description="Generate experimental hair helper bones (hair_grp_*).",
        )
        enable_cloth_assist_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Cloth Assist",
            default=False,
            description="Generate experimental cloth helper bones (cloth_grp_*).",
        )
        enable_film_extension_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Film Extension",
            default=False,
            description="Generate modular film helper joints (film_*).",
        )
        enable_film_facial_plugin_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Film Facial Plugin",
            default=False,
            description="Attach detachable facial helper joints (film_face_*).",
        )
        motion_preset_id: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="Motion Preset ID",
            default="",
            description="Optional motion preset ID served by the API (e.g., Wind_001).",
        )
        preset_query: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="Preset Search",
            default="",
            description="Search string for motion presets (fetched from API index).",
        )
        preset_search_limit: bpy.props.IntProperty(  # type: ignore[attr-defined]
            name="Search Limit",
            default=60,
            min=1,
            max=500,
        )
        preset_results: bpy.props.CollectionProperty(  # type: ignore[attr-defined]
            name="Preset Results",
            type=AutoRigPresetSearchResult,
        )
        preset_results_index: bpy.props.IntProperty(  # type: ignore[attr-defined]
            name="Preset Result Index",
            default=0,
            min=0,
        )
        preset_search_status: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="Preset Status",
            default="",
        )
        motion_direction: bpy.props.FloatVectorProperty(  # type: ignore[attr-defined]
            name="Direction",
            size=3,
            default=(0.0, 1.0, 0.0),
            description="Override motion direction vector (x,y,z).",
        )
        motion_intensity: bpy.props.FloatProperty(  # type: ignore[attr-defined]
            name="Intensity",
            default=0.3,
            min=0.0,
            max=2.0,
        )
        motion_frequency: bpy.props.FloatProperty(  # type: ignore[attr-defined]
            name="Frequency",
            default=0.8,
            min=0.0,
            max=5.0,
        )
        motion_damping: bpy.props.FloatProperty(  # type: ignore[attr-defined]
            name="Damping",
            default=0.5,
            min=0.0,
            max=1.0,
        )
        rig_mode: bpy.props.EnumProperty(  # type: ignore[attr-defined]
            name="Rig Mode",
            items=[
                ("ml", "ML (Default)", "Default ML/template pipeline"),
                (
                    "geometric_inference",
                    "Geometric Inference (EXPERIMENTAL)",
                    "Use guide strokes/lines to infer skeleton before correction/export",
                ),
            ],
            default="ml",
        )

        def draw(self, context):  # noqa: D401 - Blender draw API
            layout = self.layout
            layout.prop(self, "api_url")
            layout.prop(self, "timeout_ms")
            layout.prop(self, "offline_mode")
            layout.separator()
            layout.label(text="Experimental", icon="ERROR")
            layout.prop(self, "enable_geometric_experimental")
            layout.prop(self, "enable_hair_rigging_experimental")
            layout.prop(self, "enable_cloth_assist_experimental")
            layout.prop(self, "enable_film_extension_experimental")
            layout.prop(self, "enable_film_facial_plugin_experimental")
            layout.prop(self, "motion_preset_id")

            box = layout.box()
            box.label(text="Motion Preset Browser")
            row = box.row(align=True)
            row.prop(self, "preset_query", text="")
            row.operator("autorig.preset_search", text="Search")
            row2 = box.row(align=True)
            row2.prop(self, "preset_search_limit", text="Limit")
            box.template_list(
                "AUTORIG_UL_preset_results",
                "",
                self,
                "preset_results",
                self,
                "preset_results_index",
                rows=6,
            )
            box.operator("autorig.preset_use_selected", text="Use Selected Preset")
            if self.preset_search_status:
                box.label(text=self.preset_search_status)

            col = layout.column(align=True)
            col.prop(self, "motion_direction")
            col.prop(self, "motion_intensity")
            col.prop(self, "motion_frequency")
            col.prop(self, "motion_damping")
            layout.prop(self, "rig_mode")

    CLASSES = [
        AutoRigPresetSearchResult,
        AUTORIG_UL_preset_results,
        AUTORIG_OT_preset_search,
        AUTORIG_OT_preset_use_selected,
        AutoRigPreferences,
    ]
else:
    CLASSES = []
