"""HTTP client for API-first Blender execution."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from dataclasses import dataclass


@dataclass(frozen=True)
class ApiConfig:
    base_url: str = "http://127.0.0.1:8000"
    timeout_sec: float = 15.0


def healthz(config: ApiConfig) -> bool:
    try:
        req = urllib.request.Request(f"{config.base_url}/healthz", method="GET")
        with urllib.request.urlopen(req, timeout=config.timeout_sec) as res:
            payload = json.loads(res.read().decode("utf-8"))
            return payload.get("status") == "ok"
    except (ValueError, urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return False
