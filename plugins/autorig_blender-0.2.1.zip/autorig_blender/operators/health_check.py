"""Health-check operator for local API diagnostics."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None

from ..client.api_client import ApiConfig, healthz

if bpy is not None:

    class AUTORIG_OT_health_check(bpy.types.Operator):
        bl_idname = "autorig.health_check"
        bl_label = "Check AutoRig API"

        def execute(self, context):  # noqa: D401 - Blender execute API
            prefs = context.preferences.addons["autorig_blender"].preferences
            ok = healthz(ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0))
            if ok:
                self.report({"INFO"}, "AutoRig API is healthy")
                context.scene.autorig_last_health = "healthy"
                return {"FINISHED"}
            self.report({"WARNING"}, "AutoRig API unavailable")
            context.scene.autorig_last_health = "unhealthy"
            return {"CANCELLED"}

    CLASSES = [AUTORIG_OT_health_check]
else:
    CLASSES = []
